<?php

/**
 * Event Callback Action creation.
 *
 * @author     Time.ly Network Inc.
 * @since      2.0
 *
 * @instantiator new
 * @package      AI1EC
 * @subpackage   AI1EC.Event
 */
class Ai1ec_Event_Callback_Action extends Ai1ec_Event_Callback_Abstract {
}