<?php
class Ai1ec_Api_Settings {
	const FACEBOOK_API_KEY = 'facebook_api_key';
}
