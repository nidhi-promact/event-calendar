<li><a href="<?php echo esc_attr( "#$id" ); ?>" data-toggle="ai1ec-tab">
  <?php echo esc_html( $title ); ?></a>
</li>
