<?php

/* event-popup.twig */
class __TwigTemplate_943e432a0dcbd7fe60a569412aaad985e131799f5363073300d0a6cd788b4d71 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"ai1ec-popover ai1ec-popup ";
        echo twig_escape_filter($this->env, (isset($context["popup_classes"]) ? $context["popup_classes"] : null), "html", null, true);
        echo "\">

\t";
        // line 3
        $context["category_colors"] = $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "get_runtime", array(0 => "category_colors"), "method");
        // line 4
        echo "\t";
        if ((!twig_test_empty((isset($context["category_colors"]) ? $context["category_colors"] : null)))) {
            // line 5
            echo "\t\t<div class=\"ai1ec-color-swatches\">";
            echo (isset($context["category_colors"]) ? $context["category_colors"] : null);
            echo "</div>
\t";
        }
        // line 7
        echo "
\t<span class=\"ai1ec-popup-title\">
\t\t<a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "permalink"), "html_attr");
        echo "\"
\t\t   class=\"ai1ec-load-event\"
\t\t\t>";
        // line 11
        echo $this->env->getExtension('ai1ec')->truncate($this->getAttribute((isset($context["event"]) ? $context["event"] : null), "filtered_title"));
        echo "</a>
\t\t";
        // line 12
        if (((isset($context["show_location_in_title"]) ? $context["show_location_in_title"] : null) && (!twig_test_empty($this->getAttribute((isset($context["event"]) ? $context["event"] : null), "venue"))))) {
            // line 13
            echo "\t\t\t<span class=\"ai1ec-event-location\"
\t\t\t\t>";
            // line 14
            echo twig_escape_filter($this->env, sprintf((isset($context["text_venue_separator"]) ? $context["text_venue_separator"] : null), $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "venue")), "html", null, true);
            echo "</span>
\t\t";
        }
        // line 16
        echo "\t\t";
        if (((isset($context["is_ticket_button_enabled"]) ? $context["is_ticket_button_enabled"] : null) && (!twig_test_empty($this->getAttribute((isset($context["event"]) ? $context["event"] : null), "ticket_url"))))) {
            // line 17
            echo "\t\t\t<a class=\"ai1ec-pull-right ai1ec-btn ai1ec-btn-primary ai1ec-btn-xs
\t\t\t\tai1ec-buy-tickets\" target=\"_blank\"
\t\t\t\thref=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "ticket_url"), "html_attr");
            echo "\"
\t\t\t\t>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "ticket_url_label"), "html", null, true);
            echo "</a>
\t\t";
        }
        // line 22
        echo "\t</span>

\t";
        // line 24
        if ((!twig_test_empty($this->getAttribute((isset($context["event"]) ? $context["event"] : null), "edit_post_link")))) {
            // line 25
            echo "\t\t<a class=\"post-edit-link\" href=\"";
            echo $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "edit_post_link");
            echo "\">
\t\t\t<i class=\"ai1ec-fa ai1ec-fa-pencil\"></i> ";
            // line 26
            echo twig_escape_filter($this->env, (isset($context["text_edit"]) ? $context["text_edit"] : null), "html", null, true);
            echo "
\t\t</a>
\t";
        }
        // line 29
        echo "
\t<div class=\"ai1ec-event-time\">
\t\t";
        // line 31
        if (twig_test_empty((isset($context["popup_timespan"]) ? $context["popup_timespan"] : null))) {
            // line 32
            echo "\t\t\t";
            echo $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "timespan_short");
            echo "
\t\t";
        } else {
            // line 34
            echo "\t\t\t";
            echo (isset($context["popup_timespan"]) ? $context["popup_timespan"] : null);
            echo "
\t\t";
        }
        // line 36
        echo "\t</div>

\t";
        // line 38
        if ((!twig_test_empty($this->getAttribute((isset($context["event"]) ? $context["event"] : null), "avatar_not_wrapped")))) {
            // line 39
            echo "\t\t<a class=\"ai1ec-load-event\"
\t\t\thref=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "permalink"), "html_attr");
            echo "\">
\t\t\t";
            // line 41
            echo $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "avatar_not_wrapped");
            echo "
\t\t</a>
\t";
        }
        // line 44
        echo "
\t";
        // line 45
        if ((!twig_test_empty($this->getAttribute((isset($context["event"]) ? $context["event"] : null), "post_excerpt")))) {
            // line 46
            echo "\t\t<div class=\"ai1ec-popup-excerpt\">";
            echo $this->getAttribute((isset($context["event"]) ? $context["event"] : null), "post_excerpt");
            echo "</div>
\t";
        }
        // line 48
        echo "
</div>
";
    }

    public function getTemplateName()
    {
        return "event-popup.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 48,  134 => 46,  132 => 45,  129 => 44,  123 => 41,  119 => 40,  116 => 39,  114 => 38,  110 => 36,  104 => 34,  98 => 32,  96 => 31,  92 => 29,  86 => 26,  81 => 25,  79 => 24,  75 => 22,  70 => 20,  66 => 19,  62 => 17,  59 => 16,  54 => 14,  51 => 13,  49 => 12,  45 => 11,  40 => 9,  36 => 7,  30 => 5,  27 => 4,  25 => 3,  19 => 1,);
    }
}
